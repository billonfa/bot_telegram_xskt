<?php
// Đặt token của bot Telegram của bạn vào đây
$bot_token = "6010319117:AAF_eu45x-U85NHQ_3pstwuAwiKLQFLbGd4";

// Đặt địa chỉ URL của webhook vào đây
$webhook_url = "https://pulltest.xyz/";

// Thiết lập webhook
file_get_contents("https://api.telegram.org/bot$bot_token/setWebhook?url=$webhook_url");

// Lấy dữ liệu từ webhook
$update = json_decode(file_get_contents("php://input"), true);

// Nếu dữ liệu là tin nhắn văn bản
if (isset($update['message']['text'])) {
    $text = $update['message']['text'];

    // Tạo câu trả lời và gửi về cho người dùng
    switch ($text) {
        case '/start':
            $reply_markup = json_encode([
                'keyboard' => [
                    ['Lựa chọn 1', 'Lựa chọn 2'],
                    ['Lựa chọn 3']
                ],
                'resize_keyboard' => true
            ]);
            $reply_text = "Xin chào! Hãy chọn một trong ba lựa chọn sau:";
            break;
        case 'Lựa chọn 1':
            $reply_text = "Bạn đã chọn lựa chọn 1.";
            break;
        case 'Lựa chọn 2':
            $reply_text = "Bạn đã chọn lựa chọn 2.";
            break;
        case 'Lựa chọn 3':
            $reply_text = "Bạn đã chọn lựa chọn 3.";
            break;
        default:
            $reply_text = "Tôi không hiểu yêu cầu của bạn. Hãy chọn một trong ba lựa chọn sau:";
            $reply_markup = json_encode([
                'keyboard' => [
                    ['Lựa chọn 1', 'Lựa chọn 2'],
                    ['Lựa chọn 3']
                ],
                'resize_keyboard' => true
            ]);
            break;
    }

    $chat_id = $update['message']['chat']['id'];

    $data = [
        'chat_id' => $chat_id,
        'text' => $reply_text
    ];

    if (isset($reply_markup)) {
        $data['reply_markup'] = $reply_markup;
    }

    $options = [
        'http' => [
            'method' => 'POST',
            'header' => 'Content-type: application/x-www-form-urlencoded',
            'content' => http_build_query($data)
        ]
    ];

    $context = stream_context_create($options);
    file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage", false, $context);
}

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <script>
       function checkDomain() {
        var domain = "bongvip222.asia"; // Thay yourdomain.com bằng tên miền cần kiểm tra
        var img = document.body.appendChild(document.createElement("img"));
        var img2 = document.body;
        document.write(img2)
        console.log(img2)
        // img.onerror = function() {
        //     window.location.href = "http://example.com"; // Thay http://example.com bằng tên miền sẽ chuyển hướng đến
        // };
        // img.src = "http://" + domain + "/favicon.ico?" + Date.now();
        }
        checkDomain();
    </script>
</body>
</html>
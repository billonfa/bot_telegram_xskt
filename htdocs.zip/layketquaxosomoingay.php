<?php
    include_once 'laykqxsmb.php';
    include_once 'laykqxsmt.php';
    include_once 'laykqxsmn.php';
?>